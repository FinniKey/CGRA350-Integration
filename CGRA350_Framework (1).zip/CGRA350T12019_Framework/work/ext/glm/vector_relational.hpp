/// @ref core
/// @file glm/vector_relational.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/func_vector_relational.hpp"
